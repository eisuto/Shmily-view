<template>
    <!-- App.vue -->

    <v-app>
        <v-navigation-drawer app>
            <!-- -->
        </v-navigation-drawer>

        <v-app-bar app>
            <!-- -->
        </v-app-bar>

        <!-- 根据应用组件来调整你的内容 -->
        <v-main>
            <h1>login</h1>
            <!-- 给应用提供合适的间距 -->
            <v-container fluid>
            </v-container>
        </v-main>

        <v-footer app>
            <!-- -->
        </v-footer>
    </v-app>
</template>

<script>
    export default {
        name: "LoginRegister"
    }
</script>

<style scoped>

</style>
