<template>
  <div>Messages Page</div>
</template>

<script>
export default {
  name: "Messages"
};
</script>

<style scoped></style>
