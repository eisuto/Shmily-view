<template>
  <div>Notification Page</div>
</template>

<script>
export default {
  name: "Notification"
};
</script>

<style scoped></style>
