<template>
  <div>Profile Page</div>
</template>

<script>
export default {
  name: "Profile"
};
</script>

<style scoped></style>
