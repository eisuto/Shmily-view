<template>
  <div>Bookmarks Page</div>
</template>

<script>
export default {
  name: "Bookmarks"
};
</script>

<style scoped></style>
