<template>
  <div>Explore Page</div>
</template>

<script>
export default {
  name: "Explore"
};
</script>

<style scoped></style>
