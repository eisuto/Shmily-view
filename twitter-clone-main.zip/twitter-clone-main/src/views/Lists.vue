<template>
  <div>Lists Page</div>
</template>

<script>
export default {
  name: "Lists"
};
</script>

<style scoped></style>
